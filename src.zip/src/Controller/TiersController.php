<?php

namespace App\Controller;

use App\Entity\Tiers;
use App\Form\TiersType;
use App\Repository\TiersRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class TiersController extends AbstractController
{
    // Liste de tous les clients
    #[Route('/clients', name: 'app_clients_list')]
    public function index(TiersRepository $tiersRepository): Response
    {
        $clients = $tiersRepository->findAll();

        return $this->render('tiers/index.html.twig', [
            'clients' => $clients,
            'singleTier' => false,
        ]);
    }

    // Création d'un nouveau client
    #[Route('/clients/new', name: 'app_clients_new')]
    public function new(Request $request, EntityManagerInterface $entityManager): Response
    {
        $tier = new Tiers();
        $form = $this->createForm(TiersType::class, $tier);

        // Handle la soumission du formulaire
        $form->handleRequest($request);

        if ($form->isSubmitted()) {
            if ($form->isValid()) {
                $entityManager->persist($tier);
                $entityManager->flush();

                $this->addFlash('success', 'Client ajouté avec succès.');

                // Redirection vers la liste des clients après ajout
                return $this->redirectToRoute('app_clients_list');
            } else {
                // Ajouter un message flash si le formulaire n'est pas valide
                $this->addFlash('error', 'Le formulaire contient des erreurs, veuillez vérifier les champs.');
            }
        }

        return $this->render('tiers/new.html.twig', [
            'form' => $form,
        ]);
    }

    // Affichage d’un client spécifique
    #[Route('/tiers/{id}', name: 'app_tiers_show', requirements: ['id' => '\\d+'])]
    public function show(Tiers $tier): Response
    {
        return $this->render('tiers/index.html.twig', [
            'clients' => [$tier],
            'singleTier' => true,
        ]);
    }
}
