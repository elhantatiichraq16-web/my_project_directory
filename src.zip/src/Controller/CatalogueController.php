<?php

namespace App\Controller;

use App\Entity\Catalogues;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class CatalogueController extends AbstractController
{
    #[Route('/catalogues', name: 'catalogue_list')]
    public function index(EntityManagerInterface $em): Response
    {
        $catalogues = $em->getRepository(Catalogues::class)->findAll();

        return $this->render('catalogue/index.html.twig', [
            'catalogues' => $catalogues
        ]);
    }
}
