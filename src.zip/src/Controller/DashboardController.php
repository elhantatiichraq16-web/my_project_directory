<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Repository\FactureRepository;
use App\Entity\Facture;

#[Route('/dashboard')]
class DashboardController extends AbstractController
{
    #[Route('', name: 'app_dashboard')]
    public function dashboard(FactureRepository $factureRepo): Response
    {
        // Récupérer les statistiques
        $factures = $factureRepo->findAll();
        $totalInvoices = count($factures);
        $totalHT = array_sum(array_map(fn(Facture $f) => $f->getTotalHt(), $factures));
        $totalTTC = array_sum(array_map(fn(Facture $f) => $f->getTotalTtc(), $factures));

        $paidInvoices = array_filter($factures, fn(Facture $f) => $f->getStatut() === 'Payée');
        $pendingInvoices = array_filter(
            $factures,
            fn(Facture $f) => in_array($f->getStatut(), ['Brouillon', 'Validée', 'Envoyée'], true)
        );

        $tiers = [];
        foreach ($factures as $facture) {
            if ($facture->getTier()) {
                $tiers[$facture->getTier()->getId()] = $facture->getTier();
            }
        }
        $activeClients = count($tiers);

        $sortedInvoices = $factures;
        usort($sortedInvoices, fn(Facture $a, Facture $b) => ($b->getDateCreation()?->getTimestamp() ?? 0) <=> ($a->getDateCreation()?->getTimestamp() ?? 0));

        $pendingAmount = array_sum(array_map(fn(Facture $f) => $f->getTotalTtc(), $pendingInvoices));
        $overdueAmount = array_sum(array_map(fn(Facture $f) => $f->getTotalTtc(),
            array_filter($factures, fn(Facture $f) => $f->getStatut() === 'Retard')));

        $topClients = [];
        foreach ($factures as $facture) {
            $client = $facture->getTier();
            if (!$client) {
                continue;
            }

            $clientId = $client->getId();
            if (!isset($topClients[$clientId])) {
                $topClients[$clientId] = [
                    'name' => $client->getNom() ?? 'Client #' . $clientId,
                    'amount' => 0,
                ];
            }

            $topClients[$clientId]['amount'] += $facture->getTotalTtc();
        }
        usort($topClients, fn(array $a, array $b) => $b['amount'] <=> $a['amount']);
        $topClients = array_slice($topClients, 0, 5);

        $monthLabels = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun', 'Jul', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'];
        $monthlyTotals = array_fill(1, 12, 0.0);
        $monthlyPaidTotals = array_fill(1, 12, 0.0);

        foreach ($factures as $facture) {
            $creationDate = $facture->getDateCreation();
            if (!$creationDate) {
                continue;
            }

            $monthIndex = (int) $creationDate->format('n');
            $monthlyTotals[$monthIndex] += $facture->getTotalTtc();

            if ($facture->getStatut() === 'Payée') {
                $monthlyPaidTotals[$monthIndex] += $facture->getTotalTtc();
            }
        }

        $monthlyRevenueData = [
            'labels' => $monthLabels,
            'invoiced' => array_map(
                fn(int $month) => round($monthlyTotals[$month], 2),
                range(1, 12)
            ),
            'paid' => array_map(
                fn(int $month) => round($monthlyPaidTotals[$month], 2),
                range(1, 12)
            ),
        ];

        $stats = [
            'totalInvoices' => $totalInvoices,
            'totalHT' => $totalHT,
            'totalTTC' => $totalTTC,
            'paidInvoices' => count($paidInvoices),
            'pendingInvoices' => count($pendingInvoices),
            'activeClients' => $activeClients,
            'recentInvoices' => array_slice($sortedInvoices, 0, 3),
            'pendingAmount' => $pendingAmount,
            'overdueAmount' => $overdueAmount,
            'topClients' => $topClients,
            'monthlyRevenueData' => $monthlyRevenueData,
        ];

        return $this->render('dashboard.html.twig', $stats);
    }
}