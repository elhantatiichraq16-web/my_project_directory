<?php

namespace App\Service\Ventes;

class ValidationService
{
    /**
     * Vérifie si les données de la facture sont valides
     *
     * @param array $data
     * @return bool
     */
    public function isValid(array $data): bool
    {
        // Vérifie les champs obligatoires
        if (empty($data['reference'])) {
            return false;
        }
        if (empty($data['tier'])) {
            return false;
        }
        if (empty($data['date_creation'])) {
            return false;
        }
        if (empty($data['objet'])) {
            return false;
        }

        // Vérifie la date (format YYYY-MM-DD)
        $date = \DateTime::createFromFormat('Y-m-d', $data['date_creation']);
        if (!$date || $date->format('Y-m-d') !== $data['date_creation']) {
            return false;
        }

        return true;
    }
}
