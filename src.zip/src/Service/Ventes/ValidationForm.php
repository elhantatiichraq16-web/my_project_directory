<?php

namespace App\Service\Ventes;

use App\Service\GlobalService;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\HttpFoundation\Session\Session;

class ValidationForm
{
    private ValidationService $validationService;
    private GlobalService $globalService;
    private Session $session;

    public function __construct(
        ValidationService $validationService,
        GlobalService $globalService,
        RequestStack $requestStack
    ) {
        $this->validationService = $validationService;
        $this->globalService = $globalService;

        /** @var Session $session */
        $session = $requestStack->getSession();
        $this->session = $session;
    }

    /**
     * Valide les données du formulaire facture et ajoute des messages flash
     *
     * @param array $data
     * @return bool True si toutes les données sont valides, false sinon
     */
    public function validate(array $data): bool
    {
        $errors = [];

        // Vérifier les champs obligatoires
        if (empty($data['reference'])) {
            $errors[] = 'La référence de la facture est obligatoire.';
        }
        if (empty($data['tier'])) {
            $errors[] = 'Le client est obligatoire.';
        }
        if (empty($data['date_creation'])) {
            $errors[] = 'La date de facture est obligatoire.';
        }
        if (empty($data['objet'])) {
            $errors[] = "L'objet de la facture est obligatoire.";
        }

        // Vérifier la validité des données via ValidationService
        if (!$this->validationService->isValid($data)) {
            $errors[] = 'Certaines données sont invalides.';
        }

        // Ajouter les messages flash selon les erreurs
        if (!empty($errors)) {
            foreach ($errors as $msg) {
                $this->session->getFlashBag()->add('error', $msg);
            }
            return false;
        }

        $this->session->getFlashBag()->add('success', 'La facture est valide.');
        return true;
    }
}






