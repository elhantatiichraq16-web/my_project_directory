<?php
namespace App\Service;

use App\Entity\ParamsVentes;
use App\Repository\ParamsVentesRepository;
use Doctrine\ORM\EntityManagerInterface;

class ParamsService
{
    private ParamsVentesRepository $repo;
    private EntityManagerInterface $em;

    public function __construct(ParamsVentesRepository $repo, EntityManagerInterface $em)
    {
        $this->repo = $repo;
        $this->em = $em;
    }

    public function getValue(string $module, string $key, $default = null)
    {
        $param = $this->repo->findOneBy(['module' => $module, 'cle' => $key]);
        if (!$param) {
            return $default;
        }
        $value = $param->getEtat();
        if ($value === null || $value === '') {
            $value = $param->getValeur();
        }
        return $value ?? $default;
    }

    public function setValue(string $module, string $key, $value, ?string $type = null, ?string $label = null): ParamsVentes
    {
        $param = $this->repo->findOneBy(['module' => $module, 'cle' => $key]);
        if (!$param) {
            $param = new ParamsVentes();
            $param->setModule($module);
            $param->setCle($key);
            if ($type) $param->setType($type);
            if ($label) $param->setCleLabels($label);
            $param->setCreatedAt(new \DateTimeImmutable());
            $this->em->persist($param);
        }
        // decide where to store based on type
        if ($type === 'switch') {
            $param->setEtat($value ? 'on' : 'off');
            $param->setValeur(null);
        } else {
            $param->setValeur((string)$value);
            $param->setEtat(null);
        }
        $param->setUpdatedAt(new \DateTimeImmutable());
        $this->em->flush();
        return $param;
    }
}
