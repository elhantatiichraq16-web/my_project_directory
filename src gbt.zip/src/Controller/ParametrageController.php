<?php
namespace App\Controller;

use App\Entity\ParamsVentes;
use App\Repository\ParamsVentesRepository;
use App\Service\ParamsService;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Controller additions for previewing and selecting invoice templates.
 */
class ParametrageController extends AbstractController
{
    #[Route('/parametrage/modele/{slug}', name: 'app_preview_modele')]
    public function previewModele(string $slug): Response
    {
        $invoice = [
            'number' => 'F-2025-001',
            'date' => new \DateTime(),
            'dueDate' => (new \DateTime())->modify('+30 days'),
            'items' => [
                ['description' => 'Produit A', 'quantity' => 2, 'unitPrice' => 250],
                ['description' => 'Produit B', 'quantity' => 1, 'unitPrice' => 120],
            ],
            'subtotal' => 620,
            'vatRate' => 20,
            'vat' => 124,
            'total' => 744,
            'currency' => 'MAD',
            'paymentTerms' => 'Paiement à 30 jours fin de mois'
        ];

        $company = [
            'name' => 'Ma Société SARL',
            'address' => '123 Rue Principale',
            'city' => 'Casablanca',
            'postalCode' => '20000',
            'phone' => '+212 600 000 000'
        ];

        $client = [
            'name' => 'Client Démo',
            'address' => '456 Avenue des Tests',
            'city' => 'Rabat',
            'postalCode' => '10000',
            'phone' => '+212 611 111 111'
        ];

        $template = 'invoice/' . $slug . '.html.twig';

        return $this->render($template, [
            'invoice' => $invoice,
            'company' => $company,
            'client' => $client,
        ]);
    }

    #[Route('/parametrage/modele/choisir', name: 'app_parametrage_set_modele', methods: ['POST'])]
    public function setModele(Request $request, ParamsVentesRepository $paramsVentesRepository, EntityManagerInterface $entityManager): Response
    {
        $modele = $request->request->get('modele');
        if (!$modele) {
            $this->addFlash('danger', 'Aucun modèle sélectionné.');
            return $this->redirectToRoute('app_parametrage');
        }

        // Persist the model selection into params_ventes table (cle = 'modele_facture', module = 'facture')
        $param = $paramsVentesRepository->findOneBy(['module' => 'facture', 'cle' => 'modele_facture']);
        if (!$param) {
            $param = new ParamsVentes();
            $param->setModule('facture');
            $param->setCle('modele_facture');
            $param->setType('text');
            $param->setCleLabels('Modèle de facture actif');
            $param->setCreatedAt(new \DateTimeImmutable());
            $entityManager->persist($param);
        }

        $param->setValeur($modele);
        $param->setEtat(null);
        $param->setUpdatedAt(new \DateTimeImmutable());
        $entityManager->flush();

        $this->addFlash('success', sprintf('Modèle "%s" enregistré.', $modele));

        return $this->redirectToRoute('app_parametrage');
    }

    #[Route('/parametrage/modele/{slug}/pdf', name: 'app_parametrage_modele_pdf')]
    public function previewModelePdf(string $slug): Response
    {
        // Renders the template — to convert to PDF integrate Dompdf or wkhtmltopdf in your project.
        $invoice = [
            'number' => 'F-2025-001',
            'date' => new \DateTime(),
            'dueDate' => (new \DateTime())->modify('+30 days'),
            'items' => [
                ['description' => 'Produit A', 'quantity' => 2, 'unitPrice' => 250],
                ['description' => 'Produit B', 'quantity' => 1, 'unitPrice' => 120],
            ],
            'subtotal' => 620,
            'vatRate' => 20,
            'vat' => 124,
            'total' => 744,
            'currency' => 'MAD',
            'paymentTerms' => 'Paiement à 30 jours fin de mois'
        ];

        $company = [
            'name' => 'Ma Société SARL',
            'address' => '123 Rue Principale',
            'city' => 'Casablanca',
            'postalCode' => '20000',
            'phone' => '+212 600 000 000'
        ];

        $client = [
            'name' => 'Client Démo',
            'address' => '456 Avenue des Tests',
            'city' => 'Rabat',
            'postalCode' => '10000',
            'phone' => '+212 611 111 111'
        ];

        $template = 'invoice/' . $slug . '.html.twig';
        // Simple render; if you want PDF generation use a service here (Dompdf/KnpSnappy)
        return $this->render($template, [
            'invoice' => $invoice,
            'company' => $company,
            'client' => $client,
        ]);
    }
}
